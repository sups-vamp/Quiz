Following are some points regarding the Quiz App:

UI:
1. User has a choice to select number of questions that he/she wants to attempt in both the quizzes
2. User can select a limit of numbers,i.e, questions displayed in the quiz will consist of numbers which will be below that limit
3. User cannot take the quiz until he fills both the fields in the landing page
4. Both Quizzes can work simultaneously,i.e, user can start with the second quiz in the middle of the firrst quiz
5. User cannot enter a value other than a number 
6. Score will be displayed throughout the Quiz
7. At the end of the quiz, the total score will be displayed along with the skipped/incorrect questions in red

CODE:
1. Made of pure Javascript
2. Used concept of classes and objects
3. Comments have been added for all functions
4. Used SCSS for styling